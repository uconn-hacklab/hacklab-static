use std::time::{SystemTime, UNIX_EPOCH};
use uuid::Uuid;

pub struct User {
    id: Uuid,
}
impl User {
    pub fn new() -> User {
        User { id: Uuid::new_v4() }
    }
}

impl std::string::ToString for User {
    fn to_string(&self) -> std::string::String {
        self.id.to_string()
    }
}

pub struct Transaction {
    sender: User,
    amount: f64,
    receiver: User,
    time_stamp: SystemTime,
}
impl Transaction {
    pub fn new(sender: User, receiver: User, amount: f64) -> Transaction {
        Transaction {
            sender: sender,
            amount: amount,
            receiver: receiver,
            time_stamp: SystemTime::now(),
        }
    }
}
impl std::string::ToString for Transaction {
    fn to_string(&self) -> String {
        let seconds = match &self.time_stamp.duration_since(UNIX_EPOCH) {
            Ok(dur) => dur.as_secs_f64().to_string(),
            Err(_) => panic!("Conversion from time to seconds is invalid"),
        };
        format!(
            "{}{}{}{}",
            &self.sender.to_string(),
            &self.amount,
            &self.receiver.to_string(),
            seconds
        )
    }
}
