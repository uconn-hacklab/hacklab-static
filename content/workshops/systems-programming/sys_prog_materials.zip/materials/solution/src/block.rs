use crate::transaction::Transaction;
use crate::utils::hex_to_bin;


use std::{
    vec::Vec,
    fmt,
};
use generic_array::{GenericArray, typenum::{U32}};

use sha2::{Sha256, Digest};

pub struct Block {
    pub hash: String,
    pub prev_hash: String,
    pub proof: u64,
    
    pub transactions: Vec<Transaction>,
    status: BlockStatus,    
}


    
impl Block {
    const NONCE: usize = 16; // The number of zeroes to have in front of hash in binary

    pub fn new() -> Block {
        Block {
            hash: String::new(),
            prev_hash: String::new(),
            proof: 0,
            transactions: Vec::with_capacity(0),
            status: BlockStatus { code: BlockStatus::START_BLOCK, msg: String::from("Starting block")},
        }
    }

    pub fn is_valid(&self) -> bool {
        let hash = format!("{:x}", &self.hasher(&self.proof));
        return &hash == &self.hash
    }

    pub fn add_transaction(&mut self, t: Transaction) {
        if self.status.code != BlockStatus::FROZEN {
            self.transactions.push(t);
        }
    }

    fn hasher(&self, proof: &u64) -> GenericArray<u8, U32> {
        /* Uses previous hash, time stamp, and stringified version of transactions to calculate hash*/
        let plaintext = format!("{}{}", self.to_string(), &proof);
        let mut hasher = Sha256::new();
        hasher.update(plaintext.as_bytes());

        let result: GenericArray<u8, U32> = hasher.finalize();
        result
    }

    pub fn finalize(&mut self) -> Result<BlockStatus, BlockStatus>{
        if self.status.code == BlockStatus::FROZEN {
            return Err(BlockStatus::frozen_error());
        }

        let mut proof = 0;

        loop {
            let hashed = &self.hasher(&proof);
            let binary = hex_to_bin(hashed.as_slice());
    
            let mut zero_count = 0;
            for c in binary[..Block::NONCE].chars() {
                if c != '0' {
                    break
                }
                zero_count += 1;
            } 
            println!("Proof: {} --- Hash: {:x}", &proof, &hashed );
            if zero_count == Block::NONCE {
                self.set_hashes(proof, format!("{:x}", &hashed), String::from(""));
                return Ok(BlockStatus {
                    msg: "Block successfully finalized".to_string(),
                    code: BlockStatus::FINALIZED,
                })
            }

            zero_count = 0;
            proof += 1
        }
    }

    fn set_hashes(&mut self, proof: u64, hash: String, prev_hash: String) {
        self.proof = proof;
        self.hash = hash;
        self.prev_hash = prev_hash;
        self.status = BlockStatus {
            code: BlockStatus::FROZEN,
            msg: "Block is not allowed to be mutated".to_string(),
        }
    }

}


pub struct BlockStatus {
    pub code: u32,
    pub msg: String,
}
    
impl BlockStatus {
    const FROZEN: u32 = 2;
    const FINALIZED: u32 = 1;
    const START_BLOCK: u32 = 0; // Is the start block

    pub fn frozen_error() -> BlockStatus{
        BlockStatus {
            code: BlockStatus::FROZEN,
            msg: "Block is frozen. Can't calculate proof".to_string(),
        }
    }
    


    fn code_meaning(&self) -> &str {
        match self.code {
            FINALIZED => "The block is already finalized",
            START_BLOCK => "This block is the first block created",
            _ => "An unknown error has occurred",
        }
    }
}

impl std::fmt::Display for BlockStatus {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        // TODO display code meaning if message is not given
        write!(f, "{}", self.code_meaning())
    }
}

impl std::fmt::Debug for BlockStatus {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        let status = format!("Block status {} ({}). Message: {}", self.code, self.code_meaning(), self.msg);
        write!(f, "{}", status)
    }
}


impl std::string::ToString for Block{
    fn to_string(&self) -> String {
        let mut stringified = String::from("");

        stringified.push_str(&self.prev_hash);

        for transaction in &self.transactions {
            stringified.push_str(&transaction.to_string());
        }

        stringified
    }
}

