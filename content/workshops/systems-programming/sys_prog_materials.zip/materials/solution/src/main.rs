mod block;
mod transaction;
mod utils;

use block::Block;
use transaction::{Transaction, User};

fn main() {
    let bob = User::new();
    let alice = User::new();

    let transaction = Transaction::new(bob, alice, 1.50);
    let mut b = Block::new();
    b.add_transaction(transaction);

    b.finalize();

    println!("Proof {} -- {}", &b.proof, &b.hash);
    println!("Is valid: {}", &b.is_valid());

    let bob = User::new();
    let alice = User::new();
    b.transactions.push(Transaction::new(alice, bob, 2.00));
    println!("Is valid: {}", &b.is_valid());
}
