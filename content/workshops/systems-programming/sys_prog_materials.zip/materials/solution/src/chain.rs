use bytes::Bytes;
use crate::block::Block;

struct Chain {
    blocks: Vec<Block>
}

impl Chain {

}