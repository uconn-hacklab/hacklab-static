pub fn hex_to_bin(hex: &[u8]) -> String {
    let mut bin_string = String::with_capacity(0);
    for byte in hex.iter() {
        bin_string.push_str(&format!("{:08b}", byte));
    }
    bin_string
}



