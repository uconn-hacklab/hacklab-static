// Importing files from the project https://stackoverflow.com/a/26225057
// WARNING THIS IS NOT COMPLETE ON PURPOSE! FINISH THE REST TO MAKE THE CODE WORK!!
mod utils;
mod block;
mod blockchain;
mod transaction_set;
mod transaction;
// mod  <name of module aka file here>;
// **add module for TransactionSet
// **add module for Transaction


// we specify the word "crate" because we are referring to something inside of our project
// use crate::<module_name>::<struct/function name>;
// **figure out how to import TransactionSet
// **figure out how to import Transaction
// **figure out how to import Blockchain



/* Some implementation comments:
- Convert the hashed result (which is in hexadecimal) into a binary number (see utils.rs for a function that does this)
- Use a Nonce of size 16 (meaning the binary number should start with 16 zeros)
*/

fn main() {
    println!("Hello, world!");

    // explicitly defined type generic: https://doc.rust-lang.org/rust-by-example/generics.html
    let blockchain: Blockchain<TransactionSet> = Blockchain::new(); // does mutability need to change? What type should new() return?

    blockchain.new_transaction("Linda", "Jane", 60.0); // What are the types of the parameters being put in?

    blockchain.new_transaction("Bo", "Linda", 10.0);
    blockchain.new_block(); // this finalizes the current block and adds a new current block
    blockchain.new_transaction("Linda", "Jane", 60.0); // What are the types of the parameters being put in?

    // blockchain should be valid
    println!("The blockchain is valid: {}", blockchain.is_valid()); // what type should is_valid() be?

    // tamper with the transaction. Blockchain should no longer be valid
    let prev_block = blockchain.blocks.get_mut(0).unwrap();
    prev_block.transactions.push(Transaction::new("Elon", "You", 999999.0));

    // blockchain should no longer be valid
    if !blockchain.is_valid() {
        panic!("The blockchain should be invalid after tampering the previous block!")
    }
}
