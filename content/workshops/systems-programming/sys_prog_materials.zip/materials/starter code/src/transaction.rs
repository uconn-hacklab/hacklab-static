// add required imports here (see main.rs on how to import)
// **figure out how to import Hashable trait
// **figure out how to import ToString trait

pub struct Transaction {
    // instance variables here
    // add name of first person
    // add name of second person
    // add amount
}

impl Transaction {
    // write methods here
    pub fn new() /* what should this return? */ {

    }
}


/* Generally you don't implement std::string::ToString, but in this case we are.
If you want stuff to be able to print out to the screen, you could implement it like this

    impl std::fmt::Display for BlockStatus {
        fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
            write!(f, "{}", <some string here>)
        }
    }

    impl std::fmt::Debug for BlockStatus {
        fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
            write!(f, "{}", <some string here>)
        }
    }
*/
impl Hashable for Transaction {} // we can leave this blank since there is already a default implementation in (hashable.rs)

impl std::string::ToString for Transaction{
    fn to_string(&self) -> String {

    }
}


#[cfg(test)]
mod tests {
    /* Testing documentation can be found here: 
        Lessons -----
        https://doc.rust-lang.org/book/ch11-01-writing-tests.html
        https://doc.rust-lang.org/book/ch11-03-test-organization.html

        By example -- https://doc.rust-lang.org/rust-by-example/testing/unit_testing.html
    */
    #[test]
    fn test_method_here() {

    }
}
