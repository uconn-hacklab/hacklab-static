use crate::utils;

/* Here we are making the Hashable trait "extend" the ToString trait (Hashable: std::string::ToString),
which means if we implement Hashable, we must also implement ToString
https://users.rust-lang.org/t/extending-traits/1802
*/
pub trait Hashable: std::string::ToString { // the Hashable trait "extends" the ToString trait 
    // we can add default implementations to traits
    fn hash_data(&self) -> String {
        let plaintext = self.to_string();
        let mut hasher = Sha256::new();
        hasher.update(plaintext.as_bytes());
        let result: GenericArray<u8, U32> = hasher.finalize();
        utils::hex_to_binary(result) // Note that there is no semicolon, which means we are returning w/ this statement
    }
}