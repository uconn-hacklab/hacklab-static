// add required imports here (see main.rs on how to import)
// **figure out how to import Hashable

// Enum documentation: https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html
enum BlockStatus {
    Frozen,
    StartBlock
}

pub struct Block<T> where T: Hashable + Updateable {
    // add instance variables here
    data: T
    // add the nonce variable
    // add previous hash value
    // add block status variable
}

impl<T> Block {
    pub fn new() {

    }

    // what should the mutability of this function be? 
    pub fn finalize() {
        // What do we need to do to finalize the block?
        // What status needs to be set?
    }

    // 

    // what should the mutability of this function be?
    fn compute_nonce() {
        // How do we compute the nonce?
    }
}

impl Updateable for Block<TransactionSet> {
    fn add_data(&self, transaction: Transaction) {
        self.data.add_data(transaction);
    }
}

/* Here we can add a TransactionSet specific implementation for */


/* Generally you don't implement std::string::ToString, but in this case we are.
If you want stuff to be able to print out to the screen, you could implement it like this

    impl std::fmt::Display for BlockStatus {
        fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
            write!(f, "{}", <some string here>)
        }
    }

    impl std::fmt::Debug for BlockStatus {
        fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
            write!(f, "{}", <some string here>)
        }
    }
*/
impl Hashable for Block {} // we can leave this blank since there is already a default implementation in (hashable.rs)

impl std::string::ToString for Block{
    fn to_string(&self) -> String {

    }
}



#[cfg(test)]
mod tests {
    /* Testing documentation can be found here: 
        Lessons -----
        https://doc.rust-lang.org/book/ch11-01-writing-tests.html
        https://doc.rust-lang.org/book/ch11-03-test-organization.html

        By example -- https://doc.rust-lang.org/rust-by-example/testing/unit_testing.html
    */
    #[test]
    fn test_method_here() {

    }
}
