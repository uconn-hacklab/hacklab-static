/* 
    This function is useful when you are trying to convert the hash result into 
    a binary string.
*/
pub fn hex_to_binary(hex: &[u8]) -> String {
    let mut bin_string = String::with_capacity(0);
    for byte in hex.iter() {
        bin_string.push_str(&format!("{:08b}", byte));
    }
    bin_string
}



