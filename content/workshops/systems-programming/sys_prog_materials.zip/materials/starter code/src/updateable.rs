/* Updateable basically requires us to implement how to add data for a given block datatype */
pub trait Updateable {
    fn add_data(&self, data);
}