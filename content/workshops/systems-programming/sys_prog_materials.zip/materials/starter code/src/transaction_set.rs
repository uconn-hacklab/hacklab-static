// add required imports here (see main.rs on how to import)
// import Transaction struct from transaction.rs


pub struct TransactionSet {
    // add instance variables here
    pub transactions: Vec<Transaction> // we are making this variable public just for demonstration purposes
}


// Documentation for traits here: https://doc.rust-lang.org/book/ch10-02-traits.html
impl Updateable for TransactionSet {
    // implement hashable trait here
    fn add_data(&self, data: Transaction) {
        // this should add a new transaction to the vec of 
    }
}

impl Hashable for TransactionSet {} // we can leave this blank since there is already a default implementation in (hashable.rs)

impl std::string::ToString for TransactionSet{
    fn to_string(&self) -> String {

    }
}


#[cfg(test)]
mod tests {
    /* Testing documentation can be found here: 
        Lessons -----
        https://doc.rust-lang.org/book/ch11-01-writing-tests.html
        https://doc.rust-lang.org/book/ch11-03-test-organization.html

        By example -- https://doc.rust-lang.org/rust-by-example/testing/unit_testing.html
    */
    #[test]
    fn test_method_here() {

    }
}
