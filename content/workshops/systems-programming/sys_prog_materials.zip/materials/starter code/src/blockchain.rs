// add required imports here (see main.rs on how to import)
// **figure out how to import Block
// **figure out how to import TransactionSet
// **figure out how to import Hashable trait

/* Confused on why you see the "<T>" ? Look at the documentation for generics!
https://doc.rust-lang.org/book/ch10-01-syntax.html

Confused on <T: Hashable> specifically? Look at 
https://doc.rust-lang.org/book/ch10-02-traits.html#clearer-trait-bounds-with-where-clauses
*/
pub struct Blockchain<T: Hashable> {

    // **Implement instance variables here
    // **recommend using a vec to store blocks(see documentation https://doc.rust-lang.org/std/vec/struct.Vec.html)
    blocks: Vec<Block<T>>
}


/* Confused on why you see the "<T>" ? Look at the documentation for generics!
https://doc.rust-lang.org/book/ch10-01-syntax.html

Confused on <T: Hashable> specifically? Look at 
https://doc.rust-lang.org/book/ch10-02-traits.html#clearer-trait-bounds-with-where-clauses
*/
impl<T: Hashable> Blockchain {
    pub fn is_valid() /* **return type missing */ {

    }


    /* Confused on what "Result<,>" is? Look at the documentation for Results!
    https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html */
    pub fn new_block(data: T) -> Result<String, String> {

    }

}

/* Confused on why you see the "<TransactionSet>" ? Look at the documentation for generics!
https://doc.rust-lang.org/book/ch10-01-syntax.html#in-method-definitions */
impl<TransactionSet> Blockchain {
    pub fn new_transaction(&self, /* **params missing */) /* **return type missing */ {
        let current_block = self.blocks.last().unwrap();
        current_block.add_data(Transaction::new(p1, p2, amount));
    }
}

#[cfg(test)]
mod tests {
    /* Testing documentation can be found here: 
        Lessons -----
        https://doc.rust-lang.org/book/ch11-01-writing-tests.html
        https://doc.rust-lang.org/book/ch11-03-test-organization.html

        By example -- https://doc.rust-lang.org/rust-by-example/testing/unit_testing.html
    */
    #[test]
    fn test_method_here() {

    }
}
