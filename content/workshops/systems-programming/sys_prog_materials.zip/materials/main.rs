
#![allow(warnings)]
fn main() {
    println!("Testing!");
}

// ---------------------- Structs and Enums -------------------------------- //

// An enum a collection of different possibilities
enum WeatherPatterns {
    Sunny,
    Windy,
    Rainy,
    Snowy
}

// A struct represents the attributes/characteristics of *something*
struct Animal {
    name: String,
    age: u16, // unsigned integer 16 bits
    speed: f32 // f32 stands for float 32 bits
}

// You can create structs with nameless attributes to distinguish units or something similar 
struct Meters(f64);
struct Seconds(f64);
struct MetersPerSecond(f64);

// This function only accepts inputs that are of type Meters.
// It returns the sum of x and y. It is also of type Meters
fn do_math(x: Meters, y: Meters) -> Meters {
    return Meters(x.0 + y.0);
}
fn explain_units() {
    let x = Meters(23.0);
    
    // This will fail because do_math() does not know how to work with Seconds() as input
    do_math(x, Seconds(4.0));
}


// In Rust you can attach data to each of the possibilities of an enum
// This combines a struct and enums
enum Color {
    RGB { red: u8, green: u8, blue: u8},
    HSV { hue: u8, saturation: u8, value: u8}
}

fn explain_color() -> Color {
    // These are both considered colors but they have different data
    let green: Color = Color::RGB { red: 0, green: 255, blue: 0 };
    let blue: Color = Color::HSV { hue: 30, saturation: 70, value: 90 };
}

// ----------------------- Generics ---------------------------------// 

fn explain_generics() {
    // If we wanted to store a list of numbers, we could create a type called
    // NumberVec. We could also create a new type called StringVec that stores
    // only strings.
    //
    // But what if we wanted an list of Colors? Would we need to make ColorVec?
    //
    // Thankfully, generics allow us to write one single definition of a list
    // and then we can swap in the type it depends on. The items within the 
    // angled brackets Vec<MyType> allow us to make a list/vector of MyType.
    //
    // Here are some examples

    // I could make a list of signed 32 bit integers
    let my_list_of_numbers: Vec<i32> = vec![-1, 2, -3, 4, 5];

    // I could make a list of unsigned 32 bit integers
    let my_list_of_numbers: Vec<u32> = vec![1, 2, 3, 4, 5];

    // I could make a list of unsigned 32 bit decimals
    let my_list_of_decimals: Vec<f32> = vec![1.0, 2.0, 3.0, 4.0, 5.0];

    // I could make a list of Colors. Notice I can mix the multiple color
    // definitions like RGB and HSV. This is because they are both still considered
    // of type color.
    let my_list_of_colors: Vec<Color> = vec![
        Color::RGB { red: 255, green: 255, blue: 255 },
        Color::RGB { red: 255, green: 255, blue: 255 },
        Color::HSV { hue: 0, saturation: 50, value: 75 },

        Color::RGB { red: 255, green: 255, blue: 255 },
        Color::RGB { red: 255, green: 255, blue: 255 },
        Color::RGB { red: 255, green: 255, blue: 255 },
        Color::RGB { red: 255, green: 255, blue: 255 },

        Color::HSV { hue: 0, saturation: 50, value: 75 },
        Color::HSV { hue: 0, saturation: 50, value: 75 },
        Color::HSV { hue: 0, saturation: 50, value: 75 },
    ];
}


// ----------------- Handling "empty"/null values ----------------- //
// Lets combine both Generics and Enums. Lets say we want an enum to represent
// when something may or may not exist. In this example lets say we are programming
// an application for a library database.
//
// If somebody is trying to search for a library book, the book might or might not
// exist. Maybe they typed the query wrong or the library doesn't have it.
// In normal languages, the None or NULL value fills this role. In Rust, the concept
// of Null does not exist. The inventor of "Null" once said that this was his 
// "billion dollar mistake".
//
// This is one of the philosophies of rust. If faulty states are impossible to represent,
// then you are much less likely to make a mistake.
//
// Lets create a type called Option which either is Some(Book) (meaning the book exists)
// or None (the book doesn't exist). While it may seem like "null" exists in rust, we could
// have called the Option::None anything we want. We could have called it instead
// Option::DoesNotExist.
/* 
struct Book {
    title: String
};
enum Option {
    Some(Book),
    None 
}
*/

// However this definition for Option is kind of lame. This can only tell me if there is
// or isn't a book. Why not make it work for any type? Let's use generics!
// 
// This is subtle, but you just did something extremely useful not possible in most languages.
// You can make the code you write actually indicate the possibility of a variable not existing.
//
// If I wrote a variable in python or C, I have no idea if the programmer intended for the
// variable to store NULL/None. You could accidentally try to use NULL and your program crashes.
//
// But in Rust, if something is of type Option<> you know *FOR SURE* that the value could be empty.
// If it something isn't "wrapped" by an option, then you know *FOR SURE* the value will exist. And
// if you forget to handle the Option::None case, your program will not compile.
/*
enum Option<InsertTypeHere> {
    Some(InsertTypeHere),
    None
}
struct Birthday(u32, u32, u32);

let color: Option<Color> = Some(Color::HSV { /* insert here */ })

// If you live on mars, maybe you don't have a birthday. Now you know it's possible to not have a
// birthday.
let birthday: Option<Birthday> = Option::None;
*/
// Lets try an example now!


// The other instance where enums are useful is in indcating what kinds of errors may occur
#[derive(PartialEq)]
enum AllTheWaysICanFail {
    Reason1,
    Reason2,
    Reason3,
    Reason4
}

#[derive(Debug)]
struct Book(String);
struct Library;

// This function tries to find me a book if it exists. If it doesn't, it will let me know.
fn find_library_book(title: String, l: Library) -> Option<Book> {
    if title == "The Life of Pi" {
        return Some(Book("The Life of Pi".to_string()));
    } else {
        return None
    }
}

// This function will print out the name of the book if it exists. If it does not exist,
// it will notify me.
fn explain_options()  {
    let library = Library;
    let lib_book: Option<Book> = find_library_book("100 Lifehacks".to_string(), library);

    // In rust, a "match" statement is like switch-case in other languages. Essentially
    // you are checking every possibility and doing something if the variable (in this case
    // lib_book) matches one of the possibilities.
    match lib_book {
       Some(Book(book_name)) => println!("{}", book_name),
       None => println!("There is no book... sorry")
    }

    let found_book:Book = lib_book.unwrap();
}


// ---------------------- Dealing with the Possibility of Failure ------------------ //
// In the same way we can create a type called Option to deal with something not existing,
// we can create a type to represent something either "succeeding" or "failing". 
//
// Let's call it "Result". Notice it has 2 generic parameters T and E. If something succeeds,
// it returns Result::Ok(T). If something fails, it returns Result::Err(E)
/*
enum Result<T,E> {
    Ok(T),
    Err(E)
}
*/

// Best way is to show this is with a example method. Lets say we want to connect to the wifi.
// Either the wifi connection will succeed and it will give me access to the Wifi (using
// WifiConnection). Or the wifi connection will fail and it will give me a reason it failed
// (WifiErrors)
struct WifiConnection;

#[derive(Debug)]
enum WifiErrors {
    BadName,
    BadPassword,
}

// If I plug in the wrong password, it will return an error with the reason it failed.
fn connect_to_wifi(ssid: String, password: String) -> Result<WifiConnection, WifiErrors> {
    if password == "12345" {
        return Ok(WifiConnection)
    } else {
        return Err(WifiErrors::BadPassword)
    }
}

fn explain_result() {
    // Connecting to wifi is something that could fail!
    // Rust makes sure you always cover all of your cases
    let wifi_connection = connect_to_wifi("MyNetwork".to_string(), "123456".to_string());

    match wifi_connection {
        Ok(connection) => println!("A connection was established!"),
        Err(WifiErrors::BadName) => println!("Oh look. you gave the wrong name"),
        Err(WifiErrors::BadPassword) => println!("You gave a bad password");
    } 
}


// --------------------- Borrowing and Ownership ------------------------- //
// This is the other critical thing you need to understand when working with rust.
// Variables must own their value. Other variables can temporarily borrow the value if they need
// it.
//
// There are some rules about borrowing that if not satisfied, you program will refuse to compile.
// While this is frustrating at times, this is actually for your own good.
// By following these rules, your program is much less likely to make a stupid mistake.
//
struct Book {
    title: String
}
fn do_something() {
    // Lets say we have a library book and a library patron wants to borrow it.
    // We indicate this using the "&" symbol. This gives us a "read-only" borrow of the book.
    let library_book = Book {title: "Gulliver's Travels".to_string()};
    let library_patrons_book = &library_book;


    // If I try to modify or break the book, rust will not let me. I do not have permission.
    //library_patrons_book.title = "Gullible's Travels".to_string();


    // I am deleting this variables right now to avoid confusion with something called "variable
    // shadowing". You do not need to worry about this right now.
    drop(library_patrons_book);
    drop(library_book);
    
    // If we want to give someone permission to modify a book, we have to do 2 things.
    // 1) Indicate the variable *might* change by using the "mut" keyword (short for mutable)
    // 2) We need to "mutably" borrow the book in order to be allowed to change it
    // Like so
    let mut library_book = Book {title: "Gulliver's Travels".to_string()};
    let library_owners_book = &mut library_book;

    // Lets say I also try to give somebody else this book at the same time and also change its
    // title.
    let library_patrons_book = &library_book;
    library_owners_book.title = "I can call this whatever I want! I have permission!".to_string();

    // This doesnt work!!! There is a contradiction here. Can you spot it?
    //
    // How can the library patron be able to borrow the book if the library owner
    // has it currently borrowed (mutably)?
    // If one person must have mutable access, then nobody else can have access to it.
    // That is Rule #1.
     
    
    // This is where my analogy starts to break down. Rule #2 is that you can have as many
    // read-only (immutable) borrows as you want as long as nobody else is trying to modify it
    // mutably.
    //
    // Lets say you are the curator of the National Archives that currently houses the Declaration
    // of Independence. You can put the declaration on display and, metaphorically speaking, an
    // infinite number of people can temporarily borrow it. Borrow it in the sense that they can
    // read what the declaration says as much as they want.
    //
    // (I mean realistically it's however many people can stand in front of the display that houses
    // the declaration of but ignore reality please :) )
    //
    // However lets say there is some super-important maintenance that has to happen. So the
    // curator must gain mutable access to the declaration. Idk, they maybe have to bring the
    // declaration away from the exhibit into their super secret lab. 
    // Obviously nobody else is allowed to see it during this time. This is why you can only have
    // one borrow if you are allowed to modify it, but as long as you don't modify it, as many
    // people can see it as they want. 
    let declaration_of_indep_display = "Declaration...";
    let visitor1 = &declaration_of_indep_display;
    let visitor2 = &declaration_of_indep_display;
    let visitor3 = &declaration_of_indep_display;

    // Finally, you can also transfer ownership. For instance you could transfer the declaration of
    // independence from one place to another. The "owner" has full and complete control over the
    // variable without needing to borrow it.
    let super_secret_lab = declaration_of_indep_display;
}
